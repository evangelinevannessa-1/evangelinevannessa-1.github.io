// const http = require('http');

// const server = http.createServer((req, res) => {
//   res.writeHead(200, { 'Content-Type': 'text/plain' });
//   res.end('Hello, World!\n');
// });

// server.listen(3000, () => {
//   console.log('Server running at http://localhost:3000/');
// });

const fs = require('fs');
const express = require('express');
const app = express();
const cors = require('cors');
app.use(cors());

app.use(express.json()); // For parsing JSON request bodies

app.post('/update-data', (req, res) => {
  const newData = req.body;

  // Read existing data
  fs.readFile('../data.json', 'utf8', (err, data) => {
    if (err) {
      return res.status(500).send('Error reading file');
    }
    console.log(newData);
    const jsonData = JSON.parse(data);
    console.log(jsonData);
    jsonData.push(...newData);
     // Append new data

    // Write updated data back to file
    fs.writeFile('../data.json', JSON.stringify(jsonData, null, 2), (err) => {
      if (err) {
        return res.status(500).send('Error writing file');
      }
      res.send('Data updated successfully');
    });
  });
});
app.use(cors({
  origin: '*', // Allow requests only from this origin
}));

app.listen(3000, () => console.log('Server running on port 3000'));
